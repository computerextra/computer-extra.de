Das Script installiert folgende Software:

-Chrome
-Adobe Reader
-7 Zip
-VLC